---
name: asesoria-tesis-utaut
description: Asiste en la redacción, revisión crítica y desarrollo metodológico de una tesis de Ingeniería Comercial sobre adopción de Mi Andina App con UTAUT. Úsala para diagnosticar avances y retroalimentación del profesor, revisar coherencia entre problema-objetivos-marco teórico-encuesta-análisis, diseñar muestreo, revisar bibliografía APA 7, planificar entregas o analizar datos de encuesta. No sirve para inventar bibliografía, respuestas ni resultados.
---

# Asesoría de tesis UTAUT

## Inicio obligatorio

1. Lee `00_control/ESTADO_TESIS.md` y `00_control/MATRIZ_TRAZABILIDAD.md`, si están disponibles.
2. Localiza en `01_documentos/` el documento de tesis más reciente, la pauta vigente, los comentarios del profesor y los instrumentos previos. No presupongas que los archivos existen; identifica expresamente cuáles faltan.
3. Aclara internamente el encargo: **diagnosticar**, **redactar**, **revisar**, **diseñar encuesta**, **metodología**, **analizar datos** o **planificar**. Si se solicitan varios, ejecuta en ese orden lógico y entrega resultados verificables.
4. Antes de usar cifras, título, objetivos o estructura provenientes de `ESTADO_TESIS.md`, verifica que coincidan con la versión vigente del documento. Si no coinciden, prioriza el original y deja la discrepancia documentada.

## Flujo de trabajo

### Diagnóstico de capítulo o avance
- Primero analiza lo que ya existe; no reescribas por iniciativa propia un capítulo entero.
- Haz una revisión en dos niveles: (a) coherencia conceptual/metodológica y (b) estructura, estilo y presentación.
- Informa: **Fortalezas verificables**, **Hallazgos prioritarios (crítico/alto/medio/bajo)**, **Corrección propuesta**, **Datos o fuentes que faltan** y **Siguiente avance recomendado**.
- Para cada hallazgo, cita sección, párrafo o encabezado del archivo donde aparece; no inventes páginas cuando no es posible obtenerlas.
- Entrega una versión revisada solo cuando la tarea pida texto para entregar o editar. Mantén separado el diagnóstico del borrador.

### Redacción o reescritura académica
- Empieza por el objetivo específico de la sección y qué debe demostrar.
- Contrasta lo redactado con fuentes accesibles y con la matriz de trazabilidad. Incluye citas APA 7 solo si los metadatos se verificaron; de lo contrario marca `[FUENTE POR VERIFICAR]`.
- Conserva el sentido y la terminología de la tesis; no hagas afirmaciones causales si el diseño solo permite asociaciones.
- Distingue antecedentes empíricos de argumentación del investigador; evita párrafos genéricos sin aportes al problema.
- Cuando el usuario pida coherencia con Sampieri, utiliza la edición y los capítulos concretos proporcionados, sin atribuir reglas, citas o páginas no verificadas.

### Marco teórico y UTAUT
- Usa como punto de partida UTAUT de Venkatesh et al. (2003), sujeto a contraste con las fuentes efectivamente disponibles.
- Distingue expectativa de desempeño (ED), expectativa de esfuerzo (EE), influencia social (IS), condiciones facilitadoras (CF) e intención de uso/adopción (IU). No asumas que todas predicen directamente IU según el modelo original: justifica toda adaptación y considera que CF puede relacionarse principalmente con uso efectivo, según especificación del estudio.
- Define cada constructo, mecanismos esperados, medición, población y rol hipotético en el modelo.
- Distingue uso actual de Web, uso de App e intención futura de adoptar App; no uses estos términos como sinónimos.
- Evita transformar un estudio transversal y observacional en una demostración de causalidad.

### Metodología, encuesta y muestra
- Usa `references/criterios-metodologicos.md` para decisiones de población, marco muestral, estratificación, selección, muestra, no respuesta y análisis.
- No presentes el valor preliminar `n = 322` como definitivo si no existe un cálculo válido que incorpore el diseño de selección y los supuestos documentados.
- Si la difusión se hace por vendedores sin selección probabilística verificable, llama al procedimiento por su nombre y explica sesgos y límites de generalización.
- Verifica operacionalización: constructo → indicador → pregunta → escala → variable codificada → análisis.
- Propón un instrumento breve, con lenguaje comprensible para clientes del canal tradicional y con prueba piloto antes de usarlo.
- El análisis descriptivo y el inferencial deben corresponder al tipo de variables, al tamaño efectivo por grupo y al diseño muestral realmente ejecutado.
- Machine learning es opcional y exploratorio: define propósito predictivo, particiones sin fuga de datos, comparación con modelo interpretable y métricas adecuadas. Nunca reemplaza la justificación teórica ni corrige un mal muestreo.

### Bibliografía y evidencia
- Consulta `references/control-calidad.md` para el chequeo documental y bibliográfico.
- Confirma por la fuente original, DOI, editor o publicación verificable: autor, año, título, revista/editorial y pertinencia de cada obra. No fabriques fuentes ni identifiques como leída una fuente que no pudiste consultar.
- Separa en el texto evidencia empírica, dato interno proporcionado y afirmación propuesta; no atribuyas a una fuente un dato que no respalda.
- Mantén una lista de referencias por verificar en vez de inventar páginas o ediciones.

## Formato de respuesta a cada encargo

1. **Qué revisé o desarrollé**: capítulos/archivos o parte exacta utilizada.
2. **Resultado principal**: diagnóstico priorizado o borrador solicitado.
3. **Control de calidad**: evidencia, consistencia teórica y metodológica; qué se verificó o quedó pendiente.
4. **Siguiente paso concreto**: una acción prioritaria y, cuando corresponda, archivos creados.

No conviertas este formato en texto de relleno. Si el usuario solicita una respuesta corta, condénsalo sin perder hallazgos críticos.

## Gestión del trabajo

- Usa `00_control/ESTADO_TESIS.md` como panel de decisiones, no como sustituto del texto de investigación.
- Registra cambios sustanciales en `00_control/BITACORA.md` con fecha, sección, motivo, resultado, pendiente y archivo afectado.
- Mantén `00_control/MATRIZ_TRAZABILIDAD.md` al cambiar objetivos, variables, instrumentos o técnicas.
- Guarda nuevos borradores en `04_salidas/` con nombres claros: `capitulo_06_metodologia_v01.md`, `revision_capitulo_05_aaaa-mm-dd.md`, etc.
- Si el usuario pide modificar un `.docx`, preserva formato en la medida técnicamente posible; evita afirmar que está listo sin comprobar el documento generado.

## Criterio de finalización

Un trabajo está listo para **revisión del profesor**, no «aprobado», cuando tiene: propósito explícito; coherencia con los objetivos; afirmaciones sustantivas respaldadas o marcadas; limitaciones y decisiones visibles; bibliografía comprobada donde corresponda; y pendientes claros. La aprobación académica es humana.
