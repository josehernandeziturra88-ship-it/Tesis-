# Criterios metodológicos para la tesis de adopción

Este material orienta la revisión; no sustituye la pauta oficial ni decisiones respaldadas por el profesor.

## Pregunta y alcance

- Pregunta tentativa: ¿qué factores y barreras se asocian con la intención de adoptar Mi Andina App entre clientes del canal tradicional de la zona de venta San Antonio que todavía no la usan?
- Diferenciar análisis descriptivo, asociación estadística y predicción. La inferencia causal requiere un diseño que la respalde.
- La unidad de análisis debe definirse: comercio, cliente, titular de cuenta o persona que decide/realiza pedidos. Evitar mezclar unidades.

## Población, elegibilidad y marco

1. Especificar período de extracción del marco muestral, estado de actividad comercial y criterio de «sin App».
2. Distinguir registros totales, no encontrados, válidos, clientes con App y sin App.
3. Asegurar unicidad de clientes, exclusión de duplicados y tratamiento de registros sin contacto.
4. Definir si la encuesta va dirigida a titular, administrador, encargado de compras o usuario que efectivamente utiliza canales de pedido.

## Diseño muestral

- **Aleatorio simple (MAS)**: exige marco completo y selección con probabilidad conocida. Una fórmula de MAS no demuestra por sí sola selección probabilística.
- **Estratificado probabilístico**: exige estratos exhaustivos y excluyentes, número de unidades por estrato, método de selección aleatoria dentro de cada estrato, afijación de tamaños y probabilidad de inclusión. El tamaño total puede calcularse en función de la precisión estratificada, de la asignación y del efecto de diseño; no es incorrecto hablar de intervalos de confianza para muestreo estratificado, pero deben calcularse con fórmulas apropiadas al diseño, no atribuirlas automáticamente a MAS.
- **Por conveniencia / difusión mediada por vendedores**: no garantiza probabilidades conocidas ni intervalos de confianza de diseño representativos. Informar cobertura, cuotas si las hay, tasa de respuesta y sesgos potenciales.
- Si se compara grupo con uso de Web vs. sin canal digital, verificar anticipadamente tamaños de cada grupo y potencia/precisión, evitando fijar subgrupos sin datos.
- Registrar supuestos de prevalencia, margen de error, confianza, diseño, no respuesta y fórmula implementada antes de anunciar `n`.

## Variable e instrumento

Diseñar una tabla con columnas: variable | definición operacional | hipótesis/rol | ítem(s) | escala | origen/adaptación | codificación | análisis. Considerar: ED, EE, IS, CF, IU, uso actual de Web, familiaridad digital, acceso a smartphone/conectividad, antigüedad, barreras y rol del vendedor. Incluir datos personales solo si son necesarios y autorizados.

Revisión cognitiva de preguntas, prueba piloto, tiempo de respuesta, consentimiento claro y accesibilidad digital/no digital. No medir intención de adoptar con afirmaciones que presupongan que la persona ya usa la App.

## Plan de análisis

1. Calidad del dato: faltantes, duplicados, consistencia y criterios de exclusión.
2. Descripción de muestra, canales actuales y barreras sin extrapolar indebidamente.
3. Fiabilidad de escalas si hay suficientes ítems y tamaño muestral; revisar alfa/omega según el caso y supuestos.
4. Comparación de subgrupos Web/no digital mediante técnicas acordes con tipo de variable y diseño muestral, reportando tamaños y medidas de efecto.
5. Relaciones entre constructos e intención con modelo interpretable y diagnóstico de supuestos. No atribuir causalidad.
6. ML solo como complemento si el volumen/calidad permite validación honesta; comparar desempeño contra base simple, evitar fuga, informar inestabilidad.
7. Propuestas de acción alineadas con hallazgos, factibilidad y límites del estudio.

## Riesgos de interpretación

- Sesgo de selección cuando los vendedores eligen a quién contactar.
- Sesgo de no respuesta de clientes poco digitales.
- Sesgo de deseabilidad social si la encuesta se aplica por vendedores.
- Falacia de atribuir comportamientos de una tienda a cualquier empleado encuestado.
- Riesgos de privacidad con datos comerciales y de contacto.
