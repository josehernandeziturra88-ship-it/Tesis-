# Rúbrica interna de revisión académica

Se aplica a cada capítulo o entrega. Registrar **Cumple / Parcial / No cumple / No aplica**, evidencia puntual y acción correctiva. La evaluación es una revisión de trabajo, no una calificación oficial.

| Dimensión | Preguntas de control |
|---|---|
| Propósito | ¿La sección responde al problema y al objetivo pertinente? |
| Trazabilidad | ¿Se puede seguir pregunta → objetivos → constructos → ítems → análisis? |
| Coherencia conceptual | ¿Se definen sin confusión App, Web, uso efectivo e intención futura? |
| Base científica | ¿Hay fuentes primarias pertinentes y verificadas, evitando citas inventadas? |
| Actualidad y contexto | ¿Se distingue evidencia global de datos del canal tradicional chileno? |
| Metodología | ¿Diseño, población, muestra, selección y sesgos se explican sin contradicciones? |
| Instrumento | ¿Cada pregunta mide un constructo y es entendible para el encuestado? |
| Estadística | ¿Técnicas y conclusiones coinciden con escala, diseño y tamaño efectivo? |
| Ética | ¿Se tratan consentimiento, anonimización y acceso responsable a datos? |
| Redacción | ¿Prosa formal y precisa, párrafos con argumento, sin redundancias ni causalidad indebida? |
| APA 7 | ¿Citas y referencias coinciden y sus metadatos están comprobados? |
| Retroalimentación | ¿Se puede localizar cada observación del profesor y la corrección realizada? |

## Gravedad para hallazgos

- **Crítico:** error que invalida pregunta, población, evidencia o interpretación; datos inventados; contradicción que impide defender resultados.
- **Alto:** incoherencia de variables o muestreo, fuente esencial ausente, afirmación injustificada.
- **Medio:** sección débil, operacionalización incompleta, explicación insuficiente.
- **Bajo:** mejoras de estilo, fluidez, formato o uniformidad sin alterar significado.

## Política de evidencia

Al revisar una afirmación sensible, registrar: **afirmación**, **fuente concreta**, **grado de verificación**, **interpretación permitida** y **cambio propuesto**. La búsqueda en Internet, cuando exista acceso, sirve para verificar información; no sustituye la lectura y contraste de la fuente relevante. Nunca describir una fuente como revisada solo porque aparece citada por otra.
