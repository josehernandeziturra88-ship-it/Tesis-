# Fuentes bibliográficas

Incorpora aquí PDFs o notas bibliográficas comprobables sobre UTAUT, adopción digital B2B, canal tradicional y métodos de investigación. Lleva registro de qué artículos se han leído realmente. Una cita APA 7 requiere confirmar sus metadatos.
