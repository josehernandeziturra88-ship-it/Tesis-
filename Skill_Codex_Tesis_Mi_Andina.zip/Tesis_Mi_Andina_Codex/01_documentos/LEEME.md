# Documentos del proyecto

Deposita aquí tu último avance de tesis, índice o pauta oficial, comentarios del profesor guía y co-referente, y versiones de la encuesta. Usa fechas y versiones en los nombres. Mantén el original intacto. No incluyas documentos internos de empresa en repositorios compartidos.
