# Cómo comenzar en Codex

Este espacio ya está preparado para funcionar como proyecto local con una skill personalizada. La skill vive en `.agents/skills/asesoria-tesis-utaut/SKILL.md` y las instrucciones permanentes del proyecto están en `AGENTS.md`.

## Preparación

1. Extrae esta carpeta completa y ábrela como proyecto en Codex (aplicación, CLI o extensión IDE); no abras solamente el archivo `SKILL.md`.
2. Copia a `01_documentos/` el avance más reciente, la pauta/rúbrica, las observaciones del profesor y cualquier encuesta o índice vigente. No hace falta cambiar formatos previamente.
3. Si cuentas con artículos en PDF, agrégalos a `02_fuentes/`; si hay datos de clientes, **anonimízalos primero** y guárdalos solo de forma local en `03_datos/`, evitando repositorios públicos.
4. Inicia una conversación con Codex y utiliza la skill nombrándola explícitamente, por ejemplo `$asesoria-tesis-utaut`.

## Primer prompt recomendado

> `$asesoria-tesis-utaut` Actúa como mi asesor metodológico y revisor crítico. Revisa todos los archivos presentes en `01_documentos/`, el estado preliminar en `00_control/ESTADO_TESIS.md` y la matriz de trazabilidad. **Primero realiza un diagnóstico, no reescribas la tesis todavía.** Contrasta el avance real con la pauta y observaciones del profesor, identifica contradicciones, citas sin verificar y pendientes por prioridad. Propón un plan de trabajo de cuatro hitos, dando prioridad a la metodología y la encuesta. Actualiza `00_control/ESTADO_TESIS.md` y `00_control/BITACORA.md` solo con decisiones o hallazgos sustentados. Deja el diagnóstico en `04_salidas/diagnostico_inicial.md`.

## Otros comandos útiles

**Revisión focalizada:**

> `$asesoria-tesis-utaut` Revisa el capítulo 5 del documento más reciente. Evalúa cada constructo UTAUT, la fundamentación bibliográfica y la coherencia con objetivos. Entrega observaciones priorizadas, sin inventar fuentes y sin reescribir el capítulo completo.

**Metodología:**

> `$asesoria-tesis-utaut` Desarrolla una propuesta revisable del capítulo 6. Contrasta el marco poblacional y el canal de reclutamiento con el tipo real de muestreo. Presenta alternativas defendibles y marca las decisiones que debo conversar con mi profesor.

**Encuesta:**

> `$asesoria-tesis-utaut` Propón una matriz de operacionalización y un cuestionario piloto para clientes sin App que contemple uso Web, barreras, ED, EE, IS, CF e IU. Justifica cada pregunta y evita suponer que el cliente ya usa la aplicación.

**Control de calidad:**

> `$asesoria-tesis-utaut` Haz una auditoría antes de enviar al profesor: coherencia, citas APA 7 verificadas, diseño muestral, consistencia entre objetivos e instrumento y brechas de evidencia. Deja una lista de correcciones priorizadas.

## Información importante

La carpeta incluye datos preliminares del proyecto que pueden estar desactualizados. Codex debe contrastarlos con los documentos actuales antes de usarlos en texto final. La skill organiza y revisa, pero no reemplaza las decisiones de autoría ni la retroalimentación académica.

**Comprobación de instalación:** en Codex CLI o extensión IDE, escribe `/skills` o empieza a escribir `$asesoria-tesis-utaut` para encontrarla. Si no aparece, confirma que abriste la carpeta raíz y reinicia Codex. Documentación oficial: https://learn.chatgpt.com/docs/build-skills
