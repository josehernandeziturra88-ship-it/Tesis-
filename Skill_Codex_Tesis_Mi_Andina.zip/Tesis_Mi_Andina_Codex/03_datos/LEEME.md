# Datos — confidencial

Ubicación local para bases anonimizadas y autorizadas. No guardes aquí identificadores directos de clientes, RUT, teléfonos, direcciones ni correos salvo necesidad explícita y autorización apropiada. La carpeta está excluida de Git por defecto. Antes de usar datos, revisar población, consentimiento/acceso y tratamiento de datos personales.
