# Estado de la tesis

> **Estado inicial: información preliminar de conversaciones de trabajo, pendiente de cotejo con los documentos formales más recientes.** Modificar según instrucciones del profesor y último avance validado.

**Fecha de revisión inicial del espacio:** 2026-10-24.
**Situación actual estimada:** estructura de capítulos y marco teórico en desarrollo; pendiente consolidar metodología, muestreo e instrumento con el avance más reciente.

## Tema y título tentativo

**Factores asociados a la intención de adopción de Mi Andina App en clientes de la zona de venta de San Antonio, canal tradicional de Coca-Cola Andina Chile: estudio basado en UTAUT.**

## Propósito y alcance preliminares

Analizar los factores y las barreras asociados a la intención de adopción de Mi Andina App entre clientes que todavía no la utilizan en la zona de venta 05 (San Antonio). Comparar, dentro de esa población, clientes que usan Mi Andina Web versus quienes no utilizan herramientas digitales de pedido.

## Objetivos preliminares por validar contra documento vigente

- Caracterizar a los clientes sin uso de App.
- Identificar barreras percibidas para la adopción.
- Medir dimensiones pertinentes de UTAUT e intención de adopción.
- Comparar a usuarios de Web y clientes sin canal digital.
- Analizar asociaciones entre factores UTAUT e intención.
- Proponer medidas para favorecer adopción, según los hallazgos.

## Datos de trabajo reportados anteriormente (NO validados aquí)

| Indicador | Referencia preliminar | Validar |
|---|---:|---|
| Registros zona 05 | 2.670 | Fuente, fecha de corte, definición y duplicados |
| Registros «No encontrado» | 501 | Criterios de exclusión |
| Registros válidos zona 05 | 2.169 | Consistencia con marco vigente |
| Clientes sin App | 1.958 | Elegibilidad para encuesta |
| Clientes con App | 211 | Fuera del grupo objetivo principal, si se confirma alcance |
| Muestra sugerida en discusiones | 322 | No usar como tamaño definitivo sin justificación del diseño |

No incluir estos números en versiones entregables sin fuente, fecha y aprobación contextual.

## Referentes teóricos mencionados, todos por verificar en bibliografía actual

- Modelo de Aceptación Tecnológica (TAM), Davis (1989).
- Teoría Unificada de Aceptación y Uso de Tecnología (UTAUT), Venkatesh et al. (2003).
- Otra literatura especializada a partir de archivos del usuario; nunca inventar detalles de artículos.

## Estructura de trabajo reportada

Capítulo 2: problema y contexto. Capítulo 3: objetivos. Capítulo 4: alcance. Capítulo 5: marco teórico. Capítulo 6: metodología. Capítulo 7: resultados esperados. Cotejar con la pauta oficial y no crear ni renumerar capítulos sin revisar el índice real.

## Cuestiones metodológicas por resolver

- Unidad de análisis y responsable efectivo del pedido.
- Marco poblacional definitivo y exclusiones.
- Selección probabilística real o reclutamiento a través de vendedores y sus implicancias.
- Estratos y comparación Web/no digital, con tamaños disponibles.
- Operacionalización de UTAUT y posición analítica de condiciones facilitadoras.
- Validación y piloto de la encuesta; ética y confidencialidad.
- Plan estadístico ajustado a la calidad final del dato.

## Decisiones vigentes confirmadas por usuario

A completar al revisar documentos actuales. No presuponer aprobaciones académicas.

## Próximo hito recomendado

Revisar documento más reciente, pautas e indicaciones del profesor; construir matriz de trazabilidad corregida y elaborar un borrador defendible del capítulo metodológico (diseño, población, muestra y encuesta).
