# Matriz de trazabilidad — borrador inicial

> Tabla guía. **Propuesta, no diseño aprobado.** Actualizar desde los objetivos literalmente presentes en el informe vigente. Cada fila debe permitir rastrear la investigación hasta el resultado.

| Objetivo/propósito preliminar | Constructo o dimensión | Evidencia / ítem requerido | Análisis tentativo | Estado |
|---|---|---|---|---|
| Caracterizar clientes sin App | Tamaño negocio, rol, antigüedad, dispositivo y canal de pedido | Variables de caracterización y marco poblacional | Frecuencias y distribuciones | Por definir |
| Identificar barreras | Obstáculos técnicos, comerciales y de conocimiento | Preguntas no inductivas sobre barreras | Frecuencias y categorías | Por definir |
| Medir UTAUT e intención | ED, EE, IS, CF e IU | Ítems diferenciados, escalas y fuente de adaptación | Descriptivos, consistencia interna y puntajes si procede | Por definir |
| Comparar Web frente a ausencia digital | Segmento de uso Web y variables anteriores | Pregunta filtro y/o registro confiable de canal | Comparaciones con tamaños por grupo y efectos | Por definir |
| Estudiar asociaciones con IU | Variables UTAUT y controles pertinentes | Base depurada y estrategia de medición | Modelo de asociación interpretable, según datos | Por definir |
| Elaborar propuestas | Barreras y predictores empíricos | Hallazgos documentados, factibilidad | Matriz acción-evidencia-prioridad | Por definir |

## Reglas para mantener esta matriz

Si cambia un objetivo, actualizar sus constructos, preguntas, técnica, posible capítulo de resultados y recomendación. Si no existe dato para responder a un objetivo, señalar brecha antes de prometer resultados. No formular hipótesis estadísticas automáticas sin fundamento en el marco teórico y el diseño.
