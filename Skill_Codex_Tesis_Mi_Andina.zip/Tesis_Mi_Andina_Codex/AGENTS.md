# Guía permanente del proyecto — Tesis Mi Andina App

Este directorio reúne el trabajo de investigación de Ingeniería Comercial sobre la intención de adopción de Mi Andina App en clientes del canal tradicional de Coca-Cola Andina Chile, zona de venta de San Antonio.

## Instrucciones permanentes

- Responde y redacta en español académico de Chile, preciso y sin adornos. Explica en lenguaje sencillo cuando se solicite.
- Antes de redactar o modificar, lee `00_control/ESTADO_TESIS.md`, las instrucciones o rúbrica vigentes del profesor y el documento de avance más reciente disponible en `01_documentos/`.
- Usa la skill `$asesoria-tesis-utaut` para diagnóstico, revisión, marco teórico, metodología, instrumento, análisis y redacción de la tesis.
- Distingue hechos confirmados, cifras por verificar, propuestas metodológicas, supuestos y decisiones pendientes.
- No inventes artículos, DOI, páginas, resultados, respuestas de encuestas, aprobaciones del profesor ni citas bibliográficas. Toda cita debe corresponder a una fuente comprobada.
- No sustituyas la decisión del investigador ni la aprobación del profesor. Expón alternativas y recomienda una con fundamento cuando corresponda.
- Trabaja por sección y verifica consistencia con pregunta, objetivos, variables, instrumento y análisis.
- Nunca sobrescribas un original aportado. Los borradores derivados van a `04_salidas/`; registra sus cambios y deja los archivos originales intactos.
- Evita difundir datos de clientes, teléfonos, identificadores, RUT, reportes internos y demás información empresarial confidencial. Trabaja con archivos locales anonimizados y resultados agregados.
- Al cerrar una tarea académica significativa, actualiza `00_control/ESTADO_TESIS.md`, `00_control/MATRIZ_TRAZABILIDAD.md` cuando aplique, y `00_control/BITACORA.md` con cambios y pendientes.

## Autoridad de fuentes del proyecto

1. Corrección e instrucción explícita más reciente del usuario y profesor.
2. Pauta oficial o rúbrica del curso.
3. Documento de tesis más reciente aprobado por el usuario.
4. Artículos y documentos primarios comprobables.
5. Material de trabajo preliminar, notas e inferencias claramente identificadas.

Ante contradicciones, descríbelas brevemente sin esconderlas y aplica la instrucción de mayor prioridad.
