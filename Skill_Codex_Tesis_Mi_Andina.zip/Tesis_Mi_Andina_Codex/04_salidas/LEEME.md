# Borradores y revisiones de Codex

Codex guarda aquí informes de diagnóstico, propuestas, borradores revisados y exportaciones. Nombra las versiones de forma explícita. Ningún archivo generado se considera aprobado sin validación humana.
